//
//  SideBarViewController.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 5/31/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit

class SideBar: UIViewController {

    @IBOutlet weak var imgPerfil: UIImageView!
    
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var viewHome: UIView!
    @IBOutlet weak var viewAbout: UIView!
    @IBOutlet weak var viewProfile: UIView!
    @IBOutlet weak var viewLogout: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgPerfil.roundImage()
        
        viewHome.isUserInteractionEnabled = true
        
        
        
        let homeGesture = UITapGestureRecognizer(target: self, action: #selector(self.goHome))
        viewHome.addGestureRecognizer(homeGesture)
        let aboutGesture = UITapGestureRecognizer(target: self, action: #selector(self.goAbout))
        viewAbout.addGestureRecognizer(aboutGesture)
        let profileGesture = UITapGestureRecognizer(target: self, action: #selector(self.goProfile))
        viewProfile.addGestureRecognizer(profileGesture)
        let logoutGesture = UITapGestureRecognizer(target: self, action: #selector(self.goLogout))
        viewLogout.addGestureRecognizer(logoutGesture)
        
    }
    
    @objc func goHome(){
        // do other task
        let Alert:UIAlertController = UIAlertController(title: "MenuTap", message: "Tap on Home", preferredStyle: UIAlertController.Style.alert)
        Alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        present(Alert, animated: true, completion: nil)
    }
    
    @objc func goAbout(){
        // do other task
        let Alert:UIAlertController = UIAlertController(title: "MenuTap", message: "Tap on About", preferredStyle: UIAlertController.Style.alert)
        Alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        present(Alert, animated: true, completion: nil)
    }
    
    @objc func goProfile(){
        // do other task
        let Alert:UIAlertController = UIAlertController(title: "MenuTap", message: "Tap on Profile", preferredStyle: UIAlertController.Style.alert)
        Alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        present(Alert, animated: true, completion: nil)
    }
    
    @objc func goLogout(){
        // do other task
        let Alert:UIAlertController = UIAlertController(title: "MenuTap", message: "Tap on Logout", preferredStyle: UIAlertController.Style.alert)
        Alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        present(Alert, animated: true, completion: nil)
    }

}
