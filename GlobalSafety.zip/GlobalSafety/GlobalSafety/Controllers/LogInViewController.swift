//
//  LogInViewController.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 6/4/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var tvEmail: UITextField!
    @IBOutlet weak var tvPass: UITextField!
    @IBOutlet weak var btnHide: UIButton!
    var isHidden: Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tvEmail.delegate = self
        tvPass.delegate = self
        tvPass.isSecureTextEntry = true
        
        btnHide.setImage( UIImage(named: "eye_pass2")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        btnHide.addTarget(self, action:  #selector(self.hidePass), for: UIControl.Event.touchDown)
        
        // Assign the overlay button to a stored text field
        //tvPass.rightView = btnHide
        //tvPass.rightViewMode = UITextFieldViewModeAlways

    }
    @IBAction func next(_ sender: UITextField){
        tvPass.becomeFirstResponder()
    }
    @IBAction func done(_ sender: UITextField){
        sender.resignFirstResponder()
    }
    @objc func hidePass(){
        if(isHidden == true){
        tvPass.isSecureTextEntry = false
            isHidden = false
             btnHide.setImage( UIImage(named: "eye_pass1")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        }else{
            tvPass.isSecureTextEntry = true
            isHidden = true
             btnHide.setImage( UIImage(named: "eye_pass2")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        }
    }

}
