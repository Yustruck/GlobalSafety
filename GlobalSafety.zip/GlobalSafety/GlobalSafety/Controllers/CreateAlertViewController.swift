//
//  CreateAlertViewController.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 6/13/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit

class CreateAlertViewController: UIViewController {

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    
    @IBAction func close(){
        self.dismiss(animated: true, completion: nil)
    }
}

