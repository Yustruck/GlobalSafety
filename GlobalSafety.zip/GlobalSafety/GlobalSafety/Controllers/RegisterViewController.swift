//
//  RegisterViewController.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 6/5/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit
import iOSDropDown

class RegisterViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPass: UITextField!
    @IBOutlet weak var tfPassConfirm: UITextField!
    @IBOutlet weak var btnHide: UIButton!
    @IBOutlet weak var btnHide2: UIButton!
    @IBOutlet weak var ddCountry: DropDown!
    var isHidden: Bool!
    var isHidden2: Bool!
    enum selectedTextField {
        case etfName, etfEmail, etfPass, etfPassConfirm
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tfName.delegate = self
        tfEmail.delegate = self
        tfPass.delegate = self
        tfPass.isSecureTextEntry = true
        tfPassConfirm.delegate = self
        tfPassConfirm.isSecureTextEntry = true
        
        btnHide.setImage( UIImage(named: "eye_pass2")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        btnHide.addTarget(self, action:  #selector(self.hidePass), for: UIControl.Event.touchDown)
        btnHide2.setImage( UIImage(named: "eye_pass2")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        btnHide2.addTarget(self, action:  #selector(self.hidePass2), for: UIControl.Event.touchDown)
        
        ddCountry.optionArray = ["United States", "Canada", "England"]
        //Its Id Values and its optional
        ddCountry.optionIds = [1,2,3]
        
        // The the Closure returns Selected Index and String
        //ddCountry.didSelect{(selectedText , index ,id) in
            //self.valueLabel.text = "Selected String: \(selectedText) \n index: \(index)"
        //}
        
    }
   @IBAction func next(_ sender: UITextField){
        let selectedTF = sender.placeholder
        switch selectedTF {
        case "Name":
            tfEmail.becomeFirstResponder()
        case "Email":
            tfPass.becomeFirstResponder()
        case "Password":
            tfPassConfirm.becomeFirstResponder()
        default:
            tfEmail.becomeFirstResponder()
        }
    }
    @IBAction func done(_ sender: UITextField){
        sender.resignFirstResponder()
    }
    
    @IBAction func close(){
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func hidePass(){
        if(isHidden == true){
            tfPass.isSecureTextEntry = false
            isHidden = false
            btnHide.setImage( UIImage(named: "eye_pass1")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        }else{
            tfPass.isSecureTextEntry = true
            isHidden = true
            btnHide.setImage( UIImage(named: "eye_pass2")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        }
    }
    @objc func hidePass2(){
        if(isHidden2 == true){
            tfPassConfirm.isSecureTextEntry = false
            isHidden2 = false
            btnHide2.setImage( UIImage(named: "eye_pass1")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        }else{
            tfPassConfirm.isSecureTextEntry = true
            isHidden2 = true
            btnHide2.setImage( UIImage(named: "eye_pass2")?.withRenderingMode(.alwaysOriginal), for: UIControl.State.normal)
        }
    }
    
}
