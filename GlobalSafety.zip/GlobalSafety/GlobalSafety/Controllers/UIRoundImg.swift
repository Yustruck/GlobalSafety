//
//  UIRoundFile.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 5/31/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit

extension UIImageView{
    func roundImage(){
        self.layer.cornerRadius = self.frame.size.width / 2
        self.clipsToBounds = true
    }
}
