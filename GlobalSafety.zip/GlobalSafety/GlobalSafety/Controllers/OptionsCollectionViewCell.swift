//
//  OptionsCollectionViewCell.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 6/14/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit

class OptionsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imageAlert: UIImageView!
}
