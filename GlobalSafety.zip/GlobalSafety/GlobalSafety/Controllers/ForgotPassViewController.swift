//
//  ForgotPassViewController.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 6/7/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit

class ForgotPassViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func close(){
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func done(_ sender: UITextField){
        sender.resignFirstResponder()
    }

}
