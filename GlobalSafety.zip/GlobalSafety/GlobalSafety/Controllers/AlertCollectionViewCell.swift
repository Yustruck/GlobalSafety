//
//  AlertCollectionViewCell.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 6/7/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit

class AlertCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var nameAlert: UILabel!
    @IBOutlet weak var imageAlert: UIImageView!
    
}
