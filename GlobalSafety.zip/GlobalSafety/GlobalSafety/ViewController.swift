//
//  ViewController.swift
//  GlobalSafety
//
//  Created by FUSE / People & Technology on 5/31/19.
//  Copyright © 2019 FUSE / People & Technology. All rights reserved.
//

import UIKit
import SideMenuSwift

class ViewController: UIViewController{
    
    @IBOutlet weak var optionsCollectionView: UICollectionView!
    @IBOutlet weak var rAlertsCollectionView: UICollectionView!
    @IBOutlet weak var mAlertsCollectionView: UICollectionView!
    
    //THIS WILL BE INFO FROM A JSON THAT I DONT KNOW HOW TO GET YET.
    let recentAlerts = ["Recent Alert1", "Recent Alert2", "Recent Alert3", "Recent Alert4", "Recent Alert5", "Recent Alert6"]
    
    //SAME AS THE ONE ABOVE
    let myAlerts = ["My Alert1", "My Alert2", "My Alert3", "My Alert4", "My Alert5" ]
    
    //This will be arrays of information maybe urls for imgs that I want to get from my database to load the image into the UIImageView
    //Do you recomend a cocoapod to work with images from URLs?
    //let recentAlertImgs ???
    //let myAlertsImgs ???
    
    //THIS WILL BE ONLY THIS IMAGES FOR THE OPTIONS THAT I WANT TO SEE ON THE 3RD COLLECTIONVIEWCONTROLLER
    let optionsImgs: [UIImage] = [
        UIImage(named: "1.png")!,
        UIImage(named: "2.png")!,
        UIImage(named: "3.png")!,
        UIImage(named: "4.png")!,
        UIImage(named: "5.png")!
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func MenuClicked(_ sender: Any) {
        self.sideMenuController?.revealMenu()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func close(){
        self.dismiss(animated: true, completion: nil)
    }

}
//normal View Controller delegate and dataSource to get the recent alerts to work.
extension ViewController:UICollectionViewDelegate, UICollectionViewDataSource{
    
 func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
     var ret = 2
     if collectionView == rAlertsCollectionView {
        ret = recentAlerts.count
     }else if collectionView == mAlertsCollectionView{
        ret = myAlerts.count
     }else if collectionView == optionsCollectionView{
        ret = optionsImgs.count
     }
        return ret
     }
    
 func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
 let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: "alert", for: indexPath) as? AlertCollectionViewCell
 let cell2 =  collectionView.dequeueReusableCell(withReuseIdentifier: "alert", for: indexPath) as? OptionsCollectionViewCell
 if collectionView == rAlertsCollectionView {
    //cell?.imageAlert.image = UIImage
    //cell?.nameAlert.text = String(indexPath.row)
    cell?.nameAlert.text = recentAlerts[indexPath.row]
 
    //return cell!
 }else if collectionView == mAlertsCollectionView {
    //cell?.imageAlert.image = UIImage
    //cell?.nameAlert.text = String(indexPath.row)
    cell?.nameAlert.text = myAlerts[indexPath.row]
    //this is just a test to see if i can load images like this on the CollectionView
    let imageF: UIImage = optionsImgs[indexPath.row]
    
    cell?.imageAlert.image = imageF
    
    //return cell!
 }else if collectionView == optionsCollectionView{
    //Here is where I cant get them to load on my second viewController
    let imageF: UIImage = optionsImgs[indexPath.row]
    
    cell2?.imageAlert.image = imageF
    cell2?.backgroundColor = UIColor.white
    return cell2!
    }
 
 return cell!
 }
    
    
}
